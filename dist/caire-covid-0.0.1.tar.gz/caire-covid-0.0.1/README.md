# caire-covid
Kaggle system for covid 19
